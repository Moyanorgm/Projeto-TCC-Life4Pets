<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pets Cadastrados</title>

    <!-- Custom fonts for this template-->
    <link href="../vendorUser/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../cssUser/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../cssUser/card.css"> 

</head>

<body id="page-top">

    <?php include ('header.php'); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Pets Cadastrados</h1>

                    <div class="row">

                        <div class="col-lg-12">

                            <div class="card shadow mb-4">
                                <div class="card-header py-3 text-center">
                                    <h3 class="m-0 font-weight-bold text-dark">Meus Pets</h3>
                                </div>
                                <div class="card-body" id="outsidePetList">
                                    <!-- Modal button -->
                                    <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                        Adicionar Pets
                                    </button>
                                
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Adicionar Pets</h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <input type="text" id="petName" placeholder="Nome do pet" class="form-control mb-2">
                                                    <input type="text" id="petBreed" placeholder="Raça do pet" class="form-control mb-2">
                                                    <select id="petGender" class="form-control mb-2">
                                                        <option value="Macho">Macho</option>
                                                        <option value="Fêmea">Fêmea</option>
                                                    </select>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>
                                                    <button type="button" class="btn btn-info" onclick="addPet()">Salvar Mudanças</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <script>
                                function addPet() {
                                    var name = document.getElementById('petName').value;
                                    var breed = document.getElementById('petBreed').value;
                                    var gender = document.getElementById('petGender').value;
                                
                                    if (name && breed && gender) {
                                        var list = document.getElementById('outsidePetList');  // Referenciando a lista fora do modal
                                        var entry = document.createElement('div');
                                        entry.appendChild(document.createTextNode(`${name} - ${breed} - ${gender}`));
                                        entry.className = 'list-group-item';
                                
                                        // Botão de remover
                                        var removeBtn = document.createElement('button');
                                        removeBtn.className = 'btn btn-danger btn-sm float-right';
                                        removeBtn.innerText = 'Excluir';
                                        removeBtn.onclick = function () {
                                            list.removeChild(entry);
                                        };
                                
                                        entry.appendChild(removeBtn);
                                        list.appendChild(entry);
                                
                                        // Limpar campos após adição e fechar modal
                                        document.getElementById('petName').value = '';
                                        document.getElementById('petBreed').value = '';
                                        document.getElementById('petGender').value = 'Macho'; // reset to default value
                                        $('#exampleModal').modal('hide');  // Use jQuery to hide modal if it's included in your project
                                    } else {
                                        alert("Por favor, preencha todos os campos!");
                                    }
                                }
                                </script>
                            </div>

                        </div>

                    </div>

                </div>
                <!-- /.container-fluid -->



            <?php include ('footer.php'); ?>
</body>

</html>