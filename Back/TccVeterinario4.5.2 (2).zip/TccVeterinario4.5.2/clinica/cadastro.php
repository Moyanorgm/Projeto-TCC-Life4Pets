<?php
include('conexao.php');
//////////////////////////           FUNCIONANDO atualizado         ////////////////////////



// Dados para inserção na tabela de login
$login = $mysqli->real_escape_string($_POST['login']);
$email = $mysqli->real_escape_string($_POST['email']);
$senha = $mysqli->real_escape_string($_POST['senha']); // Criptografar a senha

// Dados para inserção na tabela de cliente
$nm_unidade = $mysqli->real_escape_string($_POST['nm_unidade']);
// $imagem = $_FILES($_POST['imagem']);
$cnpj = $mysqli->real_escape_string($_POST['cnpj']);
$cep = $mysqli->real_escape_string($_POST['cep']);
$estado = $mysqli->real_escape_string($_POST['estado']);
$cidade = $mysqli->real_escape_string($_POST['cidade']);
$bairro = $mysqli->real_escape_string($_POST['bairro']);
$rua = $mysqli->real_escape_string($_POST['rua']);
$nr = $mysqli->real_escape_string($_POST['nr']);
$celular = $mysqli->real_escape_string($_POST['celular']);

// Verificar se o email já está cadastrado
$sql_verificar_email = "SELECT id FROM tb_login_clinica WHERE email = '$email'";
$resultado_verificar_email = $mysqli->query($sql_verificar_email);
if ($resultado_verificar_email->num_rows > 0) {
    echo "<script>alert('Este email já está cadastrado.'); window.location.href = 'cadastro.php';</script>";
    exit; // Parar a execução do script se o email já estiver cadastrado
}

// Verificar se o CNPJ já está cadastrado
$sql_verificar_cnpj = "SELECT id FROM tb_clinica WHERE cnpj = '$cnpj'";
$resultado_verificar_cnpj = $mysqli->query($sql_verificar_cnpj);
if ($resultado_verificar_cnpj->num_rows > 0) {
    echo "<script>alert('Este CNPJ já está cadastrado.'); window.location.href = 'cadastro.php';</script>";
    exit; // Parar a execução do script se o CNPJ já estiver cadastrado
}

// Iniciar uma transação
$mysqli->begin_transaction();

try {
    // Inserir dados na tabela de login
    $sql_login = "INSERT INTO tb_login_clinica (login, email, senha) VALUES ('$login', '$email', '$senha')";
    $mysqli->query($sql_login);

    // Recuperar o ID do login inserido
    $login_clinica = $mysqli->insert_id;

    // Inserir dados na tabela de cliente com a chave estrangeira para login_id
    $sql_clinica = "INSERT INTO tb_clinica (nm_unidade, login_clinica, cnpj, imagem, cep, estado, cidade, bairro, rua, nr_end, celular) VALUES ('$nm_unidade', '$login_clinica', '$cnpj', '$imagem', '$cep', '$estado', '$cidade', '$bairro', '$rua', '$nr_end', '$celular')";
    $mysqli->query($sql_clinica);

    // Confirmar a transação
    $mysqli->commit();

    echo "<script>alert('Dados inseridos com sucesso.'); window.location.href = 'login.php';</script>";
} catch (Exception $e) {
    // Reverter a transação em caso de erro
    $mysqli->rollback();

    echo "<script>alert('Erro ao inserir dados: " . $e->getMessage() . "'); window.location.href = 'cadastro.php';</script>";
}

// Fechar conexão
$mysqli->close();
    

?>