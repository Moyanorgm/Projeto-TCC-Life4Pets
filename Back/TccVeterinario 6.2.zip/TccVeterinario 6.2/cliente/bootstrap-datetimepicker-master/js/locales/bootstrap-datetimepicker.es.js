/**
 * Spanish translation for bootstrap-datetimepicker
 * Bruno Bonamin <bruno.bonamin@gmail.com>
 */
;(function($){
	$.fn.datetimepicker.dates['es'] = {
		days: ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"],
		daysShort: ["Dom", "Seg", "Ter", "Quar", "Qui", "Sex", "Sáb", "Dom"],
		daysMin: ["Dom", "Seg", "Ter", "Quar", "Qui", "Sex", "Sab", "Dom"],
		months: ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outobro", "Novembro", "Dezembro"],
		monthsShort: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"],
		today: "Hoy",
		suffix: [],
		meridiem: []
	};
}(jQuery));
