<?php
include('conexao.php');
session_start();
$cliente_id = $_COOKIE["email"]; 

$nm_veterinario = $mysqli->real_escape_string(trim($_POST['nm_veterinario']));
$idade_vet = $mysqli->real_escape_string(trim($_POST['idade_vet']));
$ds_vet = $mysqli->real_escape_string(trim($_POST['ds_vet']));
$img_vet = $mysqli->real_escape_string(trim($_POST['img_vet']));
$crmv = $mysqli->real_escape_string(trim($_POST['crmv']));
$ds_especialidade = $mysqli->real_escape_string(trim($_POST['ds_especialidade']));

// $insert1 = "INSERT INTO `tb_paciente`( `nm_animal`,`idade`, `peso`, `cor`,`especie_id`,`raca_id`,`sexo`, `castrado`, `cliente_id`) VALUES ('$nm_animal','$idade','$peso','$cor','$especie_id','$raca_id','$sexo','$castrado','$cliente_id')";

$resultado = $mysqli->query($insert1);

if($resultado){
    header("location: select_veterinarios.php");
    echo "<script>alert('O veterinario foi cadastrado com sucesso!!!');</script>";
}
else{
    header("location: insert_veterinario.php");
    echo "<script>alert('Erro ao cadastrar o veterinario!!');</script>";
}

?>