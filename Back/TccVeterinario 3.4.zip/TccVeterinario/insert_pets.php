<?php
include('conexao.php');
session_start();
$cliente_id = $_COOKIE["email"]; 
$nm_animal = $mysqli->real_escape_string(trim($_POST['nm_animal']));
$idade = $mysqli->real_escape_string(trim($_POST['idade']));
$peso = $mysqli->real_escape_string(trim($_POST['peso']));
$cor = $mysqli->real_escape_string(trim($_POST['cor']));
$ds_especie = $mysqli->real_escape_string(trim($_POST['ds_especie']));
$ds_raca = $mysqli->real_escape_string(trim($_POST['ds_raca']));
$sexo = $mysqli->real_escape_string(trim($_POST['sexo']));
$castrado = $mysqli->real_escape_string(trim($_POST['castrado']));



// $insert1 = "INSERT INTO `tb_paciente`( `nm_animal`,`idade`, `peso`, `cor`,`especie_id`,`raca_id`,`sexo`, `castrado`, `cliente_id`) VALUES ('$nm_animal','$idade','$peso','$cor','$especie_id','$raca_id','$sexo','$castrado','$cliente_id')";

$resultado = $mysqli->query($insert1);

if($resultado){
    header("location: usuario.php");
    echo "<script>alert('Seu Pet foi cadastrado com sucesso!!!');</script>";
}
else{
    header("location: insert_pets.php");
    echo "<script>alert('Erro ao cadastrar seu Pet!!');</script>";
}

?>