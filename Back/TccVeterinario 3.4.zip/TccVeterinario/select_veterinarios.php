                <!-- CLINICA -->
                <!-- selecionar os Veterinarios cadastrados -->
                <?php
include('conexao.php');
session_start();

// $select = " SELECT clini.nm_unidade, clini.endereco, clini.email, clini.imagem, e.especialidade FROM tb_clinica as clini INNER JOIN tb_especialidade as e ON clini.id = e.id;";

$resultado = $mysqli->query($select);
while($dados = $resultado->fetch_array()){

    $img_vet = $dados['img_veterinario'];
    $idade_vet = $dados['idade_vet'];
    $nm_vet = $dados['nm_veterinario'];
    $ds_vet = $dados['ds_veterinario'];
    $especialidade = $dados['especialidade'];
    $crmv = $dados['crmv'];

    $card = "
    <div class='card mb-3 ' style='heigth: 540px;'>
        <div class='row row-cols-1 row-cols-md-2 g-4'>

            // <div class='col-md-4'>
            //     <img src='$img_veterinario' class='img-fluid rounded-5  ' alt=''>
            // </div>
            <div class='col-md-8'>
                <div class='card-body'>
                    <h5 class='card-title'></h5>
                    <p class='card-text'>Nome do veterinario: $nm_veterinario</p></h6>
                    <p><h6>Idade do veterinario: $idade_vet</p></h6>
                    <p><h6>Descrição do veterinario: $ds_veterinario</p></h6>
                    <p><h6>Especialidade: $especialidade</p></h6>
                    <p><h6>Crmv: $crmv</p></h6>
                    
                    <a href='cadastrar-cliente.php' class='btn btn-primary'>Cadastrar</a>
                </div> 
            </div>

        </div>
    </div>
";
echo $card;
}


if($result){
    while($row = mysqli_fetch_assoc($result)){
        echo "Nome" . $row['nm_responsavel'] . "<br>";
    }
}

?>