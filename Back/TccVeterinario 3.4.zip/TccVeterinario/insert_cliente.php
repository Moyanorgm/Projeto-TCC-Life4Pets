<?php
include('conexao.php');
session_start();
$cliente_id = $_COOKIE["email"]; 

$nm_responsavel = $mysqli->real_escape_string(trim($_POST['nm_responsavel']));
$documento_cpf = $mysqli->real_escape_string(trim($_POST['documento_cpf']));
$login_id = $mysqli->real_escape_string(trim($_POST['login_id']));
$estado_id = $mysqli->real_escape_string(trim($_POST['estado_id']));
$cidade_id = $mysqli->real_escape_string(trim($_POST['cidade_id']));
$celular = $mysqli->real_escape_string(trim($_POST['celular']));
$sexo_cliente = $mysqli->real_escape_string(trim($_POST['sexo_cliente']));




// $insert1 = "INSERT INTO `tb_paciente`( `nm_animal`,`idade`, `peso`, `cor`,`especie_id`,`raca_id`,`sexo`, `castrado`, `cliente_id`) VALUES ('$nm_animal','$idade','$peso','$cor','$especie_id','$raca_id','$sexo','$castrado','$cliente_id')";

$resultado = $mysqli->query($insert1);

if($resultado){
    header("location: usuario.php");
    echo "<script>alert('O cliente foi cadastrado com sucesso!!!');</script>";
}
else{
    header("location: insert_pets.php");
    echo "<script>alert('Erro ao cadastrar o cliente!!');</script>";
}

?>