<?php

// include('header');
                                			$sql = $mysqli->prepare("SELECT * FROM notifications_cliente WHERE cliente_id = $id ORDER BY id DESC");
                                            $sql->execute();
                                            $get = $sql->get_result();
                                            $total = $get->num_rows;
                                
                                            if($total > 0){
												$contador = 0 ;
                                                while($dados = $get->fetch_array()){

                                                    $notificacao = $dados['notificacao'];
                                                    $status = $dados['status'];
                                                    $data=$dados['data'];
                                                    switch($dados['status']){
                                                        case 0:
                                                            $status = "Não lido";
                                                        break;
                                
                                                        case 1:
                                                            $status = "Lido";
                                                        break;
                                
                                                    }
													$contador++;//
                                                    $card = 
													"<li class='nav-item dropdown no-arrow mx-1'    >
                                                    <a class='nav-link dropdown-toggle href='#' id='alertsDropdown' role='button'
                                                        data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                                                        <i class='fas fa-bell fa-fw'></i>
                                                        
                                                        <span class='badge badge-danger badge-counter'>$contador</span>
                                                    </a>
                                                    
                                                    <div class='dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in
                                                        aria-labelledby=alertsDropdown'>
                                                        <h6 class='dropdown-header border-0 style=background-color: rgb(0, 201, 221);'>
                                                            Notificações
                                                        </h6>
                                                    <a class='dropdown-item d-flex align-items-center' href=#'>
                                                    <div class='mr-3'>
                                                        <div class='icon-circle bg-primary'>
                                                            <i class='fas fa-file-alt text-white'></i>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div class='small text-gray-500'>$data</div>
                                                        <span class='font-weight-bold'>  $notificacao</span>
                                                    </div>
                                                </a>";
                                                echo $card;
												
                                                    // echo "<li>{$notificacao} | {$status}</li>";
                                                }
                                            }
                                
                                
                               
                                ?>