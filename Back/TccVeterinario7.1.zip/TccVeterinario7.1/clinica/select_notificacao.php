<?php
session_start();
include('header.php');

			$sql = $con->prepare("SELECT * FROM notifications WHERE id_para = ? ORDER BY id DESC");
			$sql->bind_param("s", $_GET['usuario']);
			$sql->execute();
			$get = $sql->get_result();
			$total = $get->num_rows;

			if($total > 0){
				while($dados = $get->fetch_array()){
					switch($dados['status']){
						case 0:
							$dados['status'] = "Não lido";
						break;

						case 1:
							$dados['status'] = "Lido";
						break;

					}
					echo "<li>{$dados['notificacao']} | {$dados['status']}</li>";
				}
			}

?>