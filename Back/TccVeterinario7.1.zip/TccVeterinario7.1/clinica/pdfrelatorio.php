<?php
include ('header.php'); 

// require '../dompdf/autoload.inc.php';
require '../vendor/autoload.php';




$html = "<!DOCTYPE html>";
$html .= "<html lang='pt-br'>";
$html .= "<head>";
$html .= "<meta charset='UTF-8'>";
$html .= "<link rel='stylesheet' href='http://localhost/TccVeterinario7.0/vendor/fontawesome-free/css/all.min.css' type='text/css'";
$html .= "<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i'";
$html .= "<link rel='stylesheet' href='http://localhost/TccVeterinario7.0/css/sb-admin-2.min.css' ";
$html .= "<link rel='stylesheet' href='http://localhost/TccVeterinario7.0/vendor/datatables/dataTables.bootstrap4.min.css' ";
$html .= "<link rel='stylesheet' href='http://localhost/TccVeterinario7.0/css/cardDia.css' ";

$html .= "<title>Lif4Pets -  PDF</title>";
$html .= "</head>";
$html .= "<body>";
$html .= "<h1>Agendamentos</h1>";


$html .="<div class='container-fluid'>";
// <!-- HEADER CONTEÚDO -->

// <!-- DataTales Example -->
$html .="<div class='card shadow mb-4'>";
$html .= "<div class='card-header py-3'>";
    $html .=       "<h3 class='m-0 font-weight-bold text-center'>Agendamentos</h3>";
        $html .=  "</div>";
$html .= "<div class='card-body'>";
                            
$html .= "<div class='table-responsive'>";
$html .= "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
$html .= "<thead>";
$html .= "<tr>";
$html .=                                    "<th>Data da Consulta</th>";
$html .=                                    "<th>Horario da Consulta</th>";
$html .=                                    "<th>Tipo de exame</th>";
$html .=                                    "<th>Cliente</th>";
$html .=                                    "<th>Paciente</th>";
$html .=                                    "<th>especialidade</th>";
$html .=                                    "<th>Descrição</th>";
$html .=                                    "<th>Status</th>";
$html .=                                "</tr>";
$html .=                            "</thead>";
$html .=                             "<tbody>";
$html .=                                "<tr>";



                                            $select3 = "SELECT cons.status, cons.hr_consulta, cons.dt_consulta, cons.ds_consulta, cons.ds_medicacao, cons.tipo_exame, cli.nm_responsavel, p.nm_animal, clini.nm_unidade, v.especialidade
               FROM tb_consulta as cons
                   INNER JOIN tb_cliente as cli ON cons.cliente_id = cli.id
                       INNER JOIN tb_paciente as p ON cons.paciente_id = p.id
                               INNER JOIN tb_veterinario as v ON cons.veterinario_id = v.id
                               INNER JOIN tb_clinica as clini ON v.clinica_id = clini.id
                                   WHERE v.clinica_id = $id 
                                   ;";
                                            
                                             $resultado3 = $mysqli->query($select3);
                                             if ($resultado3->num_rows > 0) {
                                                // $html = "<table border ='1'>";
                                                 while ($dados3 = $resultado3->fetch_array()) {
                                                    //  $dt_consulta = date("d/m/Y", strtotime($dados3['dt_consulta']));
                                                    //  $status = $dados3->status;
                                                    //  $hr_consulta = $dados3->hr_consulta;
                                                    //  $ds_consulta = $dados3->ds_consulta;
                                                    //  $tipo_exame = $dados3->tipo_exame;
                                                    //  $nm_responsavel = $dados3->nm_responsavel;
                                                    //  $nm_animal = $dados3->nm_animal;
                                                    //  $especialidade = $dados3->especialidade;
                                            
                                                     $html .= "<tr>";
                                                         $html .= "<td>"   .date("d/m/Y", strtotime($dados3['dt_consulta'])). "</td>";
                                                         $html .= "<td>"   .$dados3['hr_consulta'].  "</td>";
                                                         $html .= "<td>"   .$dados3['tipo_exame'].  "</td>";
                                                         $html .= "<td>"   .$dados3['nm_responsavel'].  "</td>";
                                                         $html .= "<td>"   .$dados3['nm_animal'].  "</td>";
                                                         $html .= "<td>"   .$dados3['especialidade'].  "</td>";
                                                         $html .= "<td>"   .$dados3['ds_consulta']. "</td>";
                                                         $html .= "<td>"   .$dados3['status'].  "</td>";

                                                        //  $html .= "</table>";
                                                 }
                                             } else {
                                                $html .= "<tr><td colspan='8'>Nenhuma consulta encontrada para hoje!</td></tr>";
                                             }
                                             $html .= "<br></tr>";
                                            
                                             $html .= "</tr>";
                                             $html .=" </tbody>";
                                             $html .="</table>";
                                             $html .="</div>";
                                             $html .="</div>";
                                             $html .="</div>";
                                             $html .="</div>";
                             
                             
                                             $html .="</div>";

$html .= "<img src=''><br>";
$html .= " <img src='localhost/TccVeterinario7.0/imgUser/LogoSFundo.jpg'><br>";
$html .= "</body>";

                                             use Dompdf\Dompdf;
                                             

                                             
                                             $dompdf = new Dompdf(['enable remote'=> true]);
                                             
                                             $dompdf-> loadHtml($html);
                                             
                                            //  $dompdf->set_option('defaultFont', 'sans');
                                             
                                             $dompdf->setPaper('A4','portrait');
                                             
                                             $dompdf->render();
                                             
                                             $dompdf->stream();
                                            //  print $html;
                                             


// gerar pdf
//  print $html;



?>




  <!-- Footer -->
  <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Lif4Pets</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
   

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script> <!--serve pra tabela tambem-->
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin-2.min.js"></script> <!--botao do sidebar-->

    <!-- Page level plugins -->
    <script src="../vendor/datatables/jquery.dataTables.min.js"></script>
    <!--Js pra funcionar os filtros da tabela-->
    <script src="../vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../js/demo/datatables-demo.js"></script>

</body>

</html>

