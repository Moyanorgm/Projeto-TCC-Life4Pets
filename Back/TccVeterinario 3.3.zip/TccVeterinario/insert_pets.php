<?php
include('conexao.php');
session_start();
$cliente_id = $_COOKIE["email"]; 

$insert1 = "INSERT INTO `tb_paciente`( `nm_animal`,`idade`, `peso`, `cor`,`especie_id`,`raca_id`,`sexo`, `castrado`, `cliente_id`) VALUES ('$nm_animal','$idade','$peso','$cor','$especie_id','$raca_id','$sexo','$castrado','$cliente_id')";


?>