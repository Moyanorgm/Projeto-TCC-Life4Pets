                                                    <!-- CLIENTES -->
<?php
include('conexao.php');
session_start();
$cliente = "1";

$select = "SELECT p.nm_animal, p.idade, p.peso, p.cor, e.ds_especie, r.raca, p.sexo, p.castrado, cli.nm_responsavel
FROM tb_paciente as p
	INNER JOIN tb_cliente as cli ON p.cliente_id = cli.id
        	INNER JOIN tb_racas as r ON p.raca_id = r.id
                	INNER JOIN tb_especie as e ON r.id_especie = e.id
                    WHERE cli.id = '$cliente';";

$resultado = $mysqli->query($select);
while($dados = $resultado->fetch_array()){

    $nm_animal = $dados['nm_animal'];
    $idade = $dados['idade'];
    $peso = $dados['peso'];
    $cor = $dados['cor'];
    $ds_especie = $dados['ds_especie'];
    $raca = $dados['raca'];
    $sexo = $dados['sexo'];
    $castrado = $dados['castrado'];
    $nm_responsavel = $dados['nm_responsavel'];

    $card = "
    <div class='card mb-3 ' style='heigth: 540px;'>
        <div class='row row-cols-1 row-cols-md-2 g-4'>

            <div class='col-md-8'>
                <div class='card-body'>
                    <h5 class='card-title'></h5>
                    <p class='card-text'>   nm_animal:  $nm_animal</p></h6>
                    <p><h6>  idade:  $idade</p></h6>
                    <p><h6>  peso: $peso</p></h6>
                    <p><h6>  cor:  $cor</p></h6>
                    <p class='card-text'>  ds_especie: $ds_especie</p></h6>
                    <p><h6>  raca:  $raca</p></h6>
                    <p><h6>  sexo:  $sexo</p></h6>
                    <p><h6>castrado:  $castrado</p></h6>
                    <p><h6>nm_responsavel:  $nm_responsavel</p></h6>

                    <a href='agendamento.php' class='btn btn-primary'>Alterar</a>
                </div> 
            </div>

        </div>
    </div>
";
echo $card;
}
?>