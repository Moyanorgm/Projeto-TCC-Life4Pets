<?php
include('conexao.php');
//////////////////////////           FUNCIONANDO mas sem "autenticação" de email           ////////////////////////
    $nm_responsavel = $mysqli->real_escape_string(trim($_POST['nm_responsavel']));
    $documento_cpf = $mysqli->real_escape_string(trim($_POST['documento_cpf']));
    $celular = $mysqli->real_escape_string(trim($_POST['celular']));
    $email = $mysqli->real_escape_string(trim($_POST['email']));
    $senha = $mysqli->real_escape_string(trim($_POST['senha']));
    $paciente_id = $mysqli->real_escape_string(trim($_POST['paciente_id']));
    $estado_id = $mysqli->real_escape_string(trim($_POST['estado_id']));
    $cidade_id = $mysqli->real_escape_string(trim($_POST['cidade_id']));

$paciente_id = 1;
$estado_id =  1 ;
$cidade_id = 1;

$insert = "INSERT INTO `tb_cliente` (`nm_responsavel`, `documento_cpf`, `celular`, `email`, `senha`, `paciente_id`, `estado_id`, `cidade_id`) VALUES ('$nm_responsavel', '$documento_cpf', '$celular', '$email', '$senha', '$paciente_id', '$estado_id', '$cidade_id')";

//echo $insert ;

$resultado = $mysqli->query($insert);

if($resultado){
    header("location: login.php");
    echo "<script>alert('Usuario cadastrado com sucesso!!');</script>";
}
else{
    header("location: cadastro.php");
    echo "<script>alert('Erro ao cadastrar usuario!!');</script>";
}
////////////////////////////////////////////////////////////////////////////////////







/////////// teste +- FUNCIONANDO  ///////// para usar este que ja esta com a autenticação de usuario para nao poder cadastrar mais de uma conta com o mesmo email, tem que fazer um select no formulario para colocar o id de cada cidade, estado, excluir o contato _id do banco, tirar o not null do paciente_id para que possa adcionar o id do paciente depois. Ou alterar somente para adcionar cep usando uma api viacep e com isso autocompletaria o formulario, alem disso teria que colcar no formulario somente o cep e o numero da residencia.

// $nm_responsavel = $mysqli->real_escape_string(trim($_POST['nm_responsavel']));
// $documento_cpf = $mysqli->real_escape_string(trim($_POST['documento_cpf']));
// $celular = $mysqli->real_escape_string(trim($_POST['celular']));
// $email = $mysqli->real_escape_string(trim($_POST['email']));
// $senha = password_hash($mysqli->real_escape_string(trim($_POST['senha'])), PASSWORD_DEFAULT);
// $paciente_id = (trim($_POST['paciente_id']));
// $estado_id = $mysqli->real_escape_string(trim($_POST['estado_id']));
// $cidade_id = $mysqli->real_escape_string(trim($_POST['cidade_id']));

// $paciente_id = 0;
// $estado_id =  1 ;
// $cidade_id = 1;



// $sql = "SELECT COUNT(*) AS total FROM tb_cliente WHERE email = '$email'";
// $result = mysqli_query($mysqli, $sql);
// $row = mysqli_fetch_assoc($result);

// if ($row['total'] > 0) {
//     // O email já está cadastrado, então você pode lidar com isso aqui
//     echo "O email já está cadastrado.";
// } else {
//     $insert = "INSERT INTO `tb_cliente` (`nm_responsavel`, `documento_cpf`, `celular`, `email`, `senha`, `paciente_id`, `estado_id`, `cidade_id`) VALUES ('$nm_responsavel', '$documento_cpf', '$celular', '$email', '$senha', '$paciente_id', '$estado_id', '$cidade_id')";

//     //echo $insert ;

//     $resultado = $mysqli->query($insert);

//     if($resultado){
//         header("location: index.php");
//         echo "<script>alert('Usuario cadastrado com sucesso!!');</script>";
//     }
//     else{
//         header("location: cadastro.php");
//         echo "<script>alert('Erro ao cadastrar usuario!!');</script>";
//     }
// }
//////////////////////////// +- FUNCIONANDO  /////////////////////////////////////////////




?>