                                                        <!-- CLINICA/CLIENTE -->
<?php
include('conexao.php');
session_start();
$nm_unidade = "Pet Center";

$select = "SELECT cons.dt_consulta, cons.ds_consulta, cons.ds_medicacao, cons.tipo_exame, cli.nm_responsavel, p.nm_animal, clini.nm_unidade, e.especialidade
FROM tb_consulta as cons
	INNER JOIN tb_cliente as cli ON cons.cliente_id = cli.id
    	INNER JOIN tb_paciente as p ON cons.paciente_id = p.id
        	INNER JOIN tb_clinica as clini ON cons.clinica_id = clini.id
            	INNER JOIN tb_especialidade as e ON cons.especialidade = e.id
                WHERE clini.nm_unidade ='$nm_unidade'
                    ORDER BY cons.dt_consulta DESC;";

$resultado = $mysqli->query($select);
while($dados = $resultado->fetch_array()){

    $dt_consulta = date("d/m/Y", strtotime($dados['dt_consulta']));
    $ds_consulta = $dados['ds_consulta'];
    $ds_medicacao = $dados['ds_medicacao'];
    $tipo_exame = $dados['tipo_exame'];
    $nm_responsavel = $dados['nm_responsavel'];
    $nm_animal = $dados['nm_animal'];
    $nm_unidade = $dados['nm_unidade'];
    $especialidade = $dados['especialidade'];

    $card = "
    <div class='card mb-3 ' style='heigth: 540px;'>
        <div class='row row-cols-1 row-cols-md-2 g-4'>

            <div class='col-md-4'>
                <img src='$imagem' class='img-fluid rounded-5  ' alt=''>
            </div>
            <div class='col-md-8'>
                <div class='card-body'>
                    <h5 class='card-title'></h5>
                    <p class='card-text'> Data da consulta:  $dt_consulta</p></h6>
                    <p><h6>Descrição da consulta:  $ds_consulta</p></h6>
                    <p><h6>Descrição da medicacao: $ds_medicacao</p></h6>
                    <p><h6>Tipo de exame:  $tipo_exame</p></h6>
                    <p class='card-text'>Nome do responsavel: $nm_responsavel</p></h6>
                    <p><h6>Nome do animal:  $nm_animal</p></h6>
                    <p><h6>Nome da unidade:  $nm_unidade</p></h6>
                    <p><h6>Especialidade:  $especialidade</p></h6>
                    <a href='agendamento.php' class='btn btn-primary'>Alterar</a>
                </div> 
            </div>

        </div>
    </div>
";
echo $card;
}
?>