<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "root";
	$dbname = "consultapet";

	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>