
<?php

// include('verificaLogin.php');
?>
    <?php include ('header.php'); ?>
    <h1></h1>
    <table border="1">
        <thead>
            <tr>
                <th>Data da Consulta</th>
                <th>Horario da Consulta</th>
                <th>Tipo de exame</th>
                <th>Cliente</th>
                <th>Paciente</th>
                <th>especialidade</th>
                <th>Descrição</th>
                <th>Status</th>
       
            </tr>
        </thead>
        <tbody>
            <?php


               $select3 = "SELECT cons.status, cons.hr_consulta, cons.dt_consulta, cons.ds_consulta, cons.ds_medicacao, cons.tipo_exame, cli.nm_responsavel, p.nm_animal, clini.nm_unidade, e.especialidade
               FROM tb_consulta as cons
                   INNER JOIN tb_cliente as cli ON cons.cliente_id = cli.id
                       INNER JOIN tb_paciente as p ON cons.paciente_id = p.id
                           INNER JOIN tb_clinica as clini ON cons.clinica_id = clini.id
                               INNER JOIN tb_especialidade as e ON cons.especialidade = e.id
                                   WHERE cons.clinica_id = $id 
                                   ;";
                            $resultado3 = $mysqli->query($select3);
                            if($resultado3->num_rows>0){
                            while($dados3 = $resultado3->fetch_array()){

                                $dt_consulta = date("d/m/Y", strtotime($dados3['dt_consulta']));
                                $status = $dados3['status'];
                                $hr_consulta = $dados3['hr_consulta'];
                                $ds_consulta = $dados3['ds_consulta'];
                                // $ds_medicacao = $dados['ds_medicacao']; 
                                $tipo_exame = $dados3['tipo_exame'];
                                $nm_responsavel = $dados3['nm_responsavel'];
                                $nm_animal = $dados3['nm_animal'];
                                $especialidade = $dados3['especialidade'];
                            
                                $card3 = "
                                <div class='container-fluid'>
                            <div class='courses-container'>
                                <div class='course'>
                                    <th> $dt_consulta </th>
                                    <th> $hr_consulta </th>
                                    <th> $tipo_exame </th>
                                    <th> $nm_responsavel </th>
                                    <th> $nm_animal </th>
                                    <th> $especialidade </th>
                                    <th> $ds_consulta </th>
                                    <th> $status </th>
                                </div>
                            </div>
                        </div>";
                        echo $card3;
                            
                            }}
                            else{
                                echo "<script>alert('Nenhuma Consulta encontrada para hoje!'); window.location.href = 'user.php';</script>";

                            }
            ?>
        </tbody>
    </table>



                            


            <?php include ('footer.php'); ?>
