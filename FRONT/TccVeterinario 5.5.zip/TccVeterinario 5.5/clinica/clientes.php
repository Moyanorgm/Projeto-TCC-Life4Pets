<?php
session_start();

?>


    <?php include ('header.php'); ?>

            


                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">  Clientes </h1>

<br>
<table border="1">
        <thead>
            <tr>
            <th> Nome do Cliente </th>
            <th> CEP </th>
            <th> Estado </th>
            <th> Cidade </th>
            <th> Bairro </th>
            <th> Rua </th>
            <th> Numero </th>
            <th> Telefone </th>
       
            </tr>
        </thead>
        <tbody>
                        <?php 

                                $select3 = " SELECT cli.nm_responsavel, cli.cep, cli.estado, cli.cidade, cli.bairro, cli.rua, cli.nr, cli.celular
                                FROM tb_consulta as cons
                                    INNER JOIN tb_cliente as cli ON cons.cliente_id = cli.id
                                            INNER JOIN tb_clinica as clini ON cons.clinica_id = clini.id
                                                    WHERE cons.clinica_id = $id ;";
                            
                            $resultado3 = $mysqli->query($select3);
                            if($resultado3->num_rows>0){
                            while($dados3 = $resultado3->fetch_array()){


                                $nm_responsavel = $dados3['nm_responsavel'];
                                $cep = $dados3['cep'];
                                $estado = $dados3['estado'];
                                // $ds_medicacao = $dados['ds_medicacao']; 
                                // $tipo_exame = $dados['tipo_exame'];
                                $cidade = $dados3['cidade'];
                                $bairro = $dados3['bairro'];
                                $rua = $dados3['rua'];
                                $nr = $dados3['nr'];
                                $celular = $dados3['celular'];

                                $card3 = "
                                <div class='container-fluid'>
                            <div class='courses-container'>
                                <div class='course'>
                                    <th> $nm_responsavel </th>
                                    <th> $cep </th>
                                    <th> $estado </th>
                                    <th> $cidade </th>
                                    <th> $bairro </th>
                                    <th> $rua </th>
                                    <th> $nr </th>
                                    <th> $celular </th>
                                </div>
                            </div>
                        </div>";
                        echo $card3;
                            
                            }}
                            else{
                                echo "<script>alert('Nenhuma Consulta encontrada para hoje!'); window.location.href = 'user.php';</script>";
                            }
                        ?>
        </tbody>
    </table>


                </div>

            </div>


            <?php include ('footer.php'); ?>
