<?php
session_start();

?>
            <?php include ('header.php'); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">  Clientes </h1>

<br>
<table border="1">
        <thead>
            <tr>
            <th>Nome do animal</th>
            <th> idade </th>
            <th> Peso </th>
            <th>  Cor</th>
            <th> Especie </th>
            <th>  Raça</th>
            <th> Sexo </th>
            <th> Castrado </th>
       
            </tr>
        </thead>
        <tbody>
                        <?php 

                                $select3 = "SELECT p.nm_animal, p.idade, p.peso, p.cor, p.especie, p.sexo, p.castrado
                                FROM tb_paciente as p 
												INNER JOIN tb_especie as e ON p.especie_id = e.id
													INNER JOIN tb_racas as r ON r.especie_id = e.id
														INNER JOIN tb_cliente as c ON p.cliente_id = c.id
                                                    WHERE p.cliente_id = '13' ;";
                            
                            $resultado3 = $mysqli->query($select3);
                            if($resultado3->num_rows>0){
                            while($dados3 = $resultado3->fetch_array()){


                                $nm_animal = $dados3['nm_animal'];
                                $idade = $dados3['idade'];
                                $peso = $dados3['peso'];
                                // $ds_medicacao = $dados['ds_medicacao']; 
                                // $tipo_exame = $dados['tipo_exame'];
                                $cor = $dados3['cor'];
                                $especie = $dados3['especie'];
                                $raca = $dados3['raca'];
                                $sexo = $dados3['sexo'];
                                $castrado = $dados3['castrado'];

                                $card3 = "
                                <div class='container-fluid'>
                            <div class='courses-container'>
                                <div class='course'>
                                    <th> $nm_responsavel </th>
                                    <th> $cep </th>
                                    <th> $estado </th>
                                    <th> $cidade </th>
                                    <th> $bairro </th>
                                    <th> $rua </th>
                                    <th> $nr </th>
                                    <th> $celular </th>
                                </div>
                            </div>
                        </div>";
                        echo $card3;
                            
                            }}
                            else{
                                echo "<script>alert('Nenhuma Consulta encontrada para hoje!'); window.location.href = 'user.php';</script>";
                            }
                        ?>
        </tbody>
    </table>


                </div>

            </div>

            <?php include ('footer.php'); ?>
