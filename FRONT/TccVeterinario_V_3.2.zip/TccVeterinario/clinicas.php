<?php
include('conexao.php');
session_start();

$select = " SELECT clini.nm_unidade, clini.endereco, clini.email, clini.imagem, e.especialidade FROM tb_clinica as clini INNER JOIN tb_especialidade as e ON clini.id = e.id;";

$resultado = $mysqli->query($select);
while($dados = $resultado->fetch_array()){

    $imagem = $dados['imagem'];
    $nm_unidade = $dados['nm_unidade'];
    $endereco = $dados['endereco'];
    $email = $dados['email'];
    $especialidade = $dados['especialidade'];
    $card = "
    <div class='card mb-3 ' style='heigth: 540px;'>
        <div class='row row-cols-1 row-cols-md-2 g-4'>

            <div class='col-md-4'>
                <img src='$imagem' class='img-fluid rounded-5  ' alt=''>
            </div>
            <div class='col-md-8'>
                <div class='card-body'>
                    <h5 class='card-title'></h5>
                    <p class='card-text'>Nome da unidade: $nm_unidade</p></h6>
                    <p><h6>Endereco: $endereco</p></h6>
                    <p><h6>Email: $email</p></h6>
                    <p><h6>Especialidade:$especialidade</p></h6>
                    <a href='agendamento.php' class='btn btn-primary'>Agendar</a>
                </div> 
            </div>

        </div>
    </div>
";
echo $card;
}


if($result){
    while($row = mysqli_fetch_assoc($result)){
        echo "Nome" . $row['nm_responsavel'] . "<br>";
    }
}

?>