<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Planos</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="assets/img/faviconProvisorio.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top d-flex align-items-center ">
        <div class="container d-flex align-items-center justify-content-between">

            <div class="logo">
                <h1><a href="index.html">Lif4Pets</a></h1>
            </div>

            <nav id="navbar" class="navbar">
                <ul>
                    <li><a class="nav-link scrollto " href="index.html">Home</a></li>
                    <li><a class="nav-link scrollto" href="planos.html">Planos</a></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav><!-- .navbar -->

        </div>
    </header><!-- End Header -->

    <main id="main">

        <!-- ======= Breadcrumbs ======= -->
        <section class="breadcrumbs">
            <div class="container">

                <div class="d-flex justify-content-between align-items-center">
                    <h2>Cadastre sua clínica</h2>
                    <ol>
                        <li><a href="index.html">Home</a></li>
                        <li>Cadastro clínica</li>
                    </ol>
                </div>

            </div>
        </section><!-- End Breadcrumbs -->

        <section class="inner-page">
            <div class="container">
                <section id="contact" class="contact">
                    <div class="container">

                        <div class="section-title aos-init aos-animate" data-aos="zoom-out">
                            <h2>Cadastro</h2>
                            <p>Cadastro Clínica</p>
                        </div>

                        <div class="row mt-5">



                            <div class="col-lg-12 mt-5 mt-lg-0 aos-init aos-animate" data-aos="fade-left">

                                <form action="" method="" role="" class="php-email-form">
                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <input type="text" name="name" class="form-control" id="name"
                                                placeholder="Nome" required="">
                                        </div>
                                        <div class="col-md-6 form-group mt-3 mt-md-0">
                                            <input type="email" class="form-control" name="email" id="email"
                                                placeholder="Email" required="">
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <input type="number" name="name" class="form-control" id="name"
                                                placeholder="CEP" required="">
                                        </div>
                                        <div class="col-md-6 form-group mt-3 mt-md-0">
                                            <input type="text" class="form-control" name="email" id="email"
                                                placeholder="Endereço" required="">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3 form-group">
                                            <input type="number" name="name" class="form-control" id="name"
                                                placeholder="Número" required="">
                                        </div>
                                        <div class="col-md-3 form-group mt-3 mt-md-0">
                                            <input type="text" class="form-control" name="email" id="email"
                                                placeholder="Bairro" required="">
                                        </div>
                                        <div class="col-md-3 form-group mt-3 mt-md-0">
                                            <input type="text" class="form-control" name="email" id="email"
                                                placeholder="Cidade" required="">
                                        </div>
                                        <div class="col-md-3 form-group mt-3 mt-md-0">
                                            <input type="text" class="form-control" name="email" id="email"
                                                placeholder="Estado" required="">
                                        </div>
                                    </div>

                                    <div class="form-group mt-3">
                                        <textarea class="form-control" name="message" rows="5"
                                            placeholder="Animais que são atendidos na clínica (Separados por Vírgula)"
                                            required=""></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 form-group">
                                            <input type="text" name="name" class="form-control" id="name"
                                                placeholder="CNPJ" required="">
                                        </div>
                                        <div class="col-md-4 form-group mt-3 mt-md-0">
                                            <input type="tel" class="form-control" name="email" id="email"
                                                placeholder="Telefone" required="">
                                        </div>
                                        <div class="col-md-4 form-group">
                                            <input type="text" name="name" class="form-control" id="name"
                                                placeholder="Whatsapp" required="">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 form-group mt-3 mt-md-0">
                                            <input type="text" class="form-control" name="email" id="email"
                                                placeholder="Login" required="">
                                        </div>
                                        <div class="col-md-6 form-group mt-3 mt-md-0">
                                            <input type="password" class="form-control" name="email" id="email"
                                                placeholder="Senha" required="">
                                        </div>
                                    </div>



                                    <div class="my-3">
                                        <div class="loading">Loading</div>
                                        <div class="error-message"></div>
                                        <div class="sent-message">Your message has been sent. Thank you!</div>
                                    </div>
                                    <div class="text-center"><button type="submit">Cadastrar</button></div>
                                </form>

                            </div>

                        </div>

                    </div>
                </section>
            </div>
        </section>

    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer">
        <div class="container">
            <h3>Lif4Pets</h3>
            <p>O Amor Começa no Cuidado</p>
            <div class="social-links">
                <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
                <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
                <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
                <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
            <div class="copyright">
                &copy; Copyright <strong><span>Lif4Pets</span></strong>. All Rights Reserved
            </div>
        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>

</body>

</html>