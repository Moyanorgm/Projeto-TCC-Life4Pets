<?php
session_start();
include ('../conexao.php');
include ('header.php');
// Consulta SQL para selecionar todos os registros da tabela tb_paciente
$sql = "SELECT cliente_id, cliente_nome, nome_pet, especie_pet, paciente_id
FROM (
    SELECT p.cliente_id AS cliente_id, c.nm_responsavel AS cliente_nome, p.nm_animal AS nome_pet, e.ds_especie AS especie_pet, p.id AS paciente_id,
    ROW_NUMBER() OVER (PARTITION BY c.id, p.nm_animal ORDER BY p.id) AS row_num
    FROM tb_paciente AS p
    INNER JOIN tb_cliente AS c ON p.cliente_id = c.id
    INNER JOIN tb_especie AS e ON p.especie_id = e.id

) AS sub
WHERE row_num = 1 AND cliente_id = $id ";


$result = $mysqli->query($sql);

$pets = [];

// Verificando se há registros retornados pela consulta
if ($result->num_rows > 0) {
    // Iterando sobre cada linha de resultados
    while ($row = $result->fetch_assoc()) {
        // Adicionando os dados do pet ao array
        $pet = [
            'nome' => $row["nome_pet"],
            'especie' => $row["especie_pet"],
            'paciente_id' => $row['paciente_id']
        ];

        // Adicionando o pet ao array de pets
        array_push($pets, $pet);
    }
} else {
    echo "Não foram encontrados registros na tabela.";
}

// // Consulta SQL para recuperar as especialidades
// $sql = "SELECT id, especialidade FROM tb_especialidade";
// $resultado = mysqli_query($mysqli, $sql);

// // Array para armazenar as especialidades
// $especialidades = array();

// // Verificar se a consulta retornou resultados
// if (mysqli_num_rows($resultado) > 0) {
//     // Loop através dos resultados da consulta e armazenar as especialidades no array
//     while ($row = mysqli_fetch_assoc($resultado)) {
//         $especialidades[$row['id']] = $row['especialidade'];
//     }
// }

// // Verificar se o formulário foi enviado e se a especialidade foi selecionada
// $especialidadeSelecionada = '';
// if (isset($_POST['especialidade'])) {
//     $especialidadeSelecionada = $_POST['especialidade'];
// }

// // Consulta SQL para recuperar as especialidades
// $sql = "SELECT id, especialidade FROM tb_especialidade";
// $resultado = mysqli_query($mysqli, $sql);

// Verificar se o parâmetro 'clinica' foi enviado via POST
if (isset($_POST['clinica'])) {
    $clinicaSelecionada = $_POST['clinica'];
    // Faça o que precisar com a clínica selecionada, como armazená-la em uma sessão
    $_SESSION['clinicaSelecionada'] = $clinicaSelecionada;


} else {
    // Redirecionar de volta para a página anterior ou exibir uma mensagem de erro
    // header("Location: petsCadastrados.php");
    exit(); // Garantir que o código seja interrompido após redirecionar
}

// Verificar se o parâmetro 'clinica' foi enviado via POST
if (isset($_POST['id'])) {
    $id_clinica = $_POST['id'];
    // Faça o que precisar com a clínica selecionada, como armazená-la em uma sessão
    $_SESSION['id_clinica'] = $id_clinica
    ;
} else {
    // Redirecionar de volta para a página anterior ou exibir uma mensagem de erro
    // header("Location: petsCadastrados.php");
    exit(); // Garantir que o código seja interrompido após redirecionar
}
$cliniid = $id_clinica;
$clinica_id = (int) $cliniid;

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"> -->

    <link rel="stylesheet" type="text/css" href="css/bootstrap-datetimepicker.min.css">

    <link href="../vendorUser/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <title>Sistema - Agendamento</title>
    <!-- Custom styles for this template-->
    <link href="../cssUser/sb-admin-2.min.css" rel="stylesheet">


    <style>
        .disabled-time {
            display: none;
        }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav sidebar sidebar-dark accordion" id="accordionSidebar"
            style="background-color: rgb(0, 201, 221); padding-top: 1rem;">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="user.php">
                <div class="sidebar-brand-icon">
                    <img src="../assets/img/LogoBrancaTotal.png" alt="" width="130rem" class="pt-2">
                </div>

            </a>


            <!-- Nav Item - Dashboard -->
            <li class="nav-item ">
                <a class="nav-link" href="user.php">
                    <i class="fas fa-home fa-sm"></i>
                    <span>Home</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="buscarCli.php">
                    <i class="fas fa-search fa-sm"></i>
                    <span>Buscar clínicas</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="minhasConsultas.php">
                    <i class="fas fa-calendar fa-2x"></i>
                    <span>Minhas consultas</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <li class="nav-item">
                <a class="nav-link" href="petsCadastrados.php">
                    <i class="fas fa-list fa-sm fa-fw mr-2"></i>
                    <span>Pets cadastrados</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="registerPet.php">
                    <i class="fas fa-arrow-right"   ></i>
                    <span>Cadastrar Pets</span></a>
            </li>

            <div class="text-center d-none d-md-inline pt-4">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3"
                        style="color:rgb(0, 201, 221); ;">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Buscar . . ."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn" style="background-color: rgb(0, 201, 221); color: white;"
                                    type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Buscar clínicas. . ." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn"
                                                style="background-color: rgb(0, 201, 221); color: white;" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter">3+</span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header border-0" style="background-color: rgb(0, 201, 221);">
                                    Notificações
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">30/01/2024</div>
                                        <span class="font-weight-bold">Novo diagnóstico pronto para download!</span>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-success">
                                            <i class="fas fa-donate text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">12/01/2024</div>
                                        Seu agendamento foi confirmado para o dia 20/02!
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-warning">
                                            <i class="fas fa-exclamation-triangle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">07/01/2024</div>
                                        Confirmar agendamento para amanhã dia 08/01/2024, 8 horas da manhã.
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Mostrar todas as
                                    notificações</a>
                            </div>
                        </li>



                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $email ?></span>
                                <!-- IMAGEM USUARIO -->
                                <img class="img-profile rounded-circle" src="<?php echo $imagem; ?>">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="perfil.php">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Perfil
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Configurações
                                </a>

                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php" data-toggle="modal"
                                    data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Sair
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <div class="container-fluid">

                    <!-- HEADER CONTEÚDO -->

                    <div class='col-lg-12 d-flex justify-content-center align-items-center'>
                        <div class='card shadow col-lg-10 p-0'>
                            <div class='card-header py-3 text-center'>
                                <h6 class='m-0 font-weight-bold text-dark'>Agendamento</h6>
                            </div>
                            <div class='card-body'>
                                <form class="row justify-content-center" action='processa.php' method='POST'>

                                    <div class="col-md-6">
                                        <?php $cliente_id = $id; ?>
                                        <div class="form-group">
                                            <label>Nome: <strong><?php echo $nm_responsavel; ?></strong></label>
                                            <input type="hidden" name="cliente_id" value="<?php echo $cliente_id; ?>">
                                        </div>

                                        <div class="form-group">
                                            <label>Clinica: <strong><?php echo $clinicaSelecionada; ?></strong></label>
                                            <input type="hidden" name="clinica_id" value="<?php echo $clinica_id; ?>">
                                        </div>

                                        <div class="form-group">
                                            <label>Pets</label>
                                            <select name="paciente_id" class="form-control">
                                                <option value="">Selecione um pet</option>
                                                <?php foreach ($pets as $pet): ?>
                                                    <option value="<?php echo $pet['paciente_id']; ?>">
                                                        <?php echo $pet['nome']; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label>Data e hora</label>
                                            <div class="input-group date data_formato"
                                                data-date-format="dd/mm/yyyy HH:ii:ss">
                                                <input class="form-control" type="text" name="dt_consulta"
                                                    placeholder="Data da consulta">
                                                <span class="input-group-addon"><span
                                                        class="glyphicon glyphicon-th"></span></span>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>Descrição</label>
                                            <textarea class="form-control" name="ds_consulta" rows="3"></textarea>
                                        </div>

                                        <div class="form-group">
                                            <button type='submit' class='btn'
                                                style='background-color: rgb(0, 201, 221); color: white;'>Agendar</button>
                                        </div>

                                        <?php
                                        if (isset($_SESSION['msg'])) {
                                            echo $_SESSION['msg'];
                                            unset($_SESSION['msg']);
                                        }
                                        ?>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>




                    <div class="col-sm-6 col-sm-offset-3" id="div_conteudo"><!-- div onde será exibido o conteúdo-->
                        <img id="loader" src="loader.gif" style="display:none;margin: 0 auto;">
                    </div>

                </div>

            </div>
            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Lif4Pets</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa"
        crossorigin="anonymous"></script>
    <script src="js/bootstrap-datetimepicker.min.js"></script>
    <script src="js\locales\bootstrap-datetimepicker.pt-BR.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {// Ao carregar a página faça o conteudo abaixo
            $('.btn_carrega_conteudo').click(function () {// Ao clicar no elemento que contenha a classe .btn_carrega_conteudo faça...
                var carrega_url = this.id; //Carregar url pegando os dados pelo ID
                carrega_url = carrega_url + '_listar.php'; //Carregar a url e o conteudo da página
                $.ajax({ //Carregar a função ajax embutida no jQuery
                    url: carrega_url,
                    //Variável DATA armazena o conteúdo da requisição
                    success: function (data) {//Caso a requisição seja completada com sucesso faça...
                        $('#div_conteudo').html(data);// Incluir o conteúdo dentro da DIV
                    },
                    beforeSend: function () {//Antes do envio do cabeçalho faça...
                        $('#loader').css({ display: "block" });//carregar a imagem de load
                    },
                    complete: function () {//Após o envio do cabeçalho faça...
                        $('#loader').css({ display: "none" });//esconder a imagem de load
                    }
                });
            });

            $('.data_formato').datetimepicker({
                weekStart: 1,
                todayBtn: 1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 2,
                forceParse: 0,
                showMeridian: 1,
                language: "pt-BR",
                startDate: '-0d'
            });
        });
    </script>

    <script src="../js/sb-admin-2.min.js"></script> <!--botao do sidebar-->

</body>


</html>